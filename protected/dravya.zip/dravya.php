<?php

return [

    'bazonim' => [
        'reference' => [
            'varga' => '',
            'name' => [
                'RU' => '',
                'LA' => '',
                'EN' => '',
                'synonyms' => ''
            ],
            'rasa_panchaka' => [
                'rasa' => '',
                'virya' => '',
                'vipaka' => '',
                'prabhava' => '',
                'guna' => '',
                'karma' => '',
            ],
            'indication' => '',
            'part_used' => '',
            'growing_area' => '',
            'description' => [
                'RU' => '',
                'SA' => '',
            ],
        ],
    ],


];